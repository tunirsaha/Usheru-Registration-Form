export const COUNTRIES_API = 'assets/json/countries.json';
export const USERNAMES_API = 'assets/json/usernames.json';
export const FORM_SUBMIT_API = 'assets/json/success-response.json';