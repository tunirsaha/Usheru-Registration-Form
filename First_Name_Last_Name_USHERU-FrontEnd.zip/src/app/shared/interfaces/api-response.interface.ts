export interface ApiResponse {
    data: any[];
    error: string;
    msg: string;
}